package cz.zcu.kiv.nlp.vs;

public enum DownloaderType {
    SELENIUM, // use only if it is necessary (e.g. cause slow JS loading ...)
    BASIC
}
