Slo�ka:
 token obsahuje v�sledek clusteringu z pouze tokenizovan�ch dat
 token_preprocess_stop 		     z token� slo�en�ch z mal�ch p�smen bez diakritiky a bez stop slov(= preprocessovan� data)
 token_stemm_prep_stop		     z token� slo�en�ch ze stemmovan�ch a preprocesovan�ch dat 